package account.rb.com.elite_agent.core.response;


import account.rb.com.elite_agent.core.APIResponse;

/**
 * Created by IN-RB on 05-02-2018.
 */

public class CommonResponse extends APIResponse {




}
