package account.rb.com.elite_agent.core.requestmodel;

/**
 * Created by IN-RB on 24-11-2018.
 */

public class RegisterRequest {


    /**
     * otp : 847560
     * agent_name : Nitin Teat
     * mobile : 7387863187
     * emailid : test1@gmail.com
     * pass : n3patil
     * pincode : 425406
     * address : chaugoan
     * area : shiv nagar
     * city : dhule
     * state : maharashtra
     * bank_account_no : 886786786786
     * IFSC_code : UYT9897Y
     * MICR_code : 78678GGJ76
     * bank_name : state bank
     * bank_branch_name : sbi
     * bank_city : virdel
     */

    private String otp;
    private String agent_name;
    private String mobile;
    private String emailid;
    private String pass;

    private String pincode;
    private String address;
    private String area;
    private String city;
    private String state;

    private String bank_account_no;
    private String IFSC_code;
    private String MICR_code;
    private String bank_name;
    private String bank_branch_name;
    private String bank_city;

    public String getOtp() {
        return otp;
    }

    public void setOtp(String otp) {
        this.otp = otp;
    }

    public String getAgent_name() {
        return agent_name;
    }

    public void setAgent_name(String agent_name) {
        this.agent_name = agent_name;
    }

    public String getMobile() {
        return mobile;
    }

    public void setMobile(String mobile) {
        this.mobile = mobile;
    }

    public String getEmailid() {
        return emailid;
    }

    public void setEmailid(String emailid) {
        this.emailid = emailid;
    }

    public String getPass() {
        return pass;
    }

    public void setPass(String pass) {
        this.pass = pass;
    }

    public String getPincode() {
        return pincode;
    }

    public void setPincode(String pincode) {
        this.pincode = pincode;
    }

    public String getAddress() {
        return address;
    }

    public void setAddress(String address) {
        this.address = address;
    }

    public String getArea() {
        return area;
    }

    public void setArea(String area) {
        this.area = area;
    }

    public String getCity() {
        return city;
    }

    public void setCity(String city) {
        this.city = city;
    }

    public String getState() {
        return state;
    }

    public void setState(String state) {
        this.state = state;
    }

    public String getBank_account_no() {
        return bank_account_no;
    }

    public void setBank_account_no(String bank_account_no) {
        this.bank_account_no = bank_account_no;
    }

    public String getIFSC_code() {
        return IFSC_code;
    }

    public void setIFSC_code(String IFSC_code) {
        this.IFSC_code = IFSC_code;
    }

    public String getMICR_code() {
        return MICR_code;
    }

    public void setMICR_code(String MICR_code) {
        this.MICR_code = MICR_code;
    }

    public String getBank_name() {
        return bank_name;
    }

    public void setBank_name(String bank_name) {
        this.bank_name = bank_name;
    }

    public String getBank_branch_name() {
        return bank_branch_name;
    }

    public void setBank_branch_name(String bank_branch_name) {
        this.bank_branch_name = bank_branch_name;
    }

    public String getBank_city() {
        return bank_city;
    }

    public void setBank_city(String bank_city) {
        this.bank_city = bank_city;
    }
}
